import { useState } from "react";
import GlowLayer from "../components/GlowLayer.jsx";
import useReveal from "../hooks/useReveal.js";
import RisingEmbers from "../components/RisingEmbers.jsx";


// Replace with the current year's committee — this list changes annually.
// "photo" is just a path string, not an import — if the file isn't
// there yet, the card falls back to the placeholder instead of crashing.
const COMMITTEE = [
  { role: "President", name: "Sourav Banerjee", photo: "/committee/president.jpg" },
  { role: "Vice President", name: "Siddhartha Sarkar", photo: "/committee/vpresident.jpg" },
  { role: "Secretary", name: "Pramita Saha", photo: "/committee/secretary.jpg" },
  { role: "Treasurer", name: "Sahadeb De", photo: "/committee/treasurer.jpg" },
  { role: "Member at large", name: "Samrat Datta", photo: "/committee/memberatlarge1.jpg" },
  { role: "Member at large", name: "Sunanda Sarkar", photo: "/committee/memberatlarge2.jpg" },
  { role: "Member at large", name: "Soumyajit Roy", photo: "/committee/memberatlarge3.jpg" },
];

export default function ExecutiveCommittee() {
  useReveal();
  return (
    <>
      <header className="page-header">
        <GlowLayer />
        <RisingEmbers count={35} />
        <span className="kicker">2026 Term</span>
        <h1>Executive Committee</h1>
        <h1 className="headline font-bangla">নেতৃত্বে</h1>
        <p>
          Ankur is run by a volunteer committee elected each year
        </p>
      </header>

    <section className="section">
      <div className="committee-grid reveal">
        {COMMITTEE.map((m) => (
          <div className="committee-card" key={m.role}>
            <div className="committee-photo-wrap">
                <CommitteePhoto src={m.photo} role={m.role} />
            </div>
            <div className="role">{m.role}</div>
            <div className="name">{m.name}</div>
          </div>
        ))}
      </div>
    </section>
    </>
  );
}

function CommitteePhoto({ src, role }) {
  const [failed, setFailed] = useState(false);

  if (!src || failed) {
    return <div className="committee-photo-placeholder">{role.charAt(0)}</div>;
  }
  return (
    <img
      className="committee-photo"
      src={src}
      alt={role}
      onError={() => setFailed(true)}
    />
  );
}
